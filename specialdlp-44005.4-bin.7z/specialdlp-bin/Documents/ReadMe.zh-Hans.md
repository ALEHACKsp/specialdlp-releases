﻿类型 | DLP 版本 | VeryCD Mod | VeryCD Tag | easyMule(1) | easyMule(2) | 默认昵称的 VeryCD 和 easyMule(1) | 其他更多吸血驴 | 修正官方问题
:---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: 
SDC | all-verycd | 软 | 无 | 软 | 硬 | 不存在 | 是 | 是
SDC | verycd-tag | 软 | 软 | 软 | 硬 | 软 | 是 | 是
SDC | verycd-nickname | 无 | 无 | 无 | 硬 | 软 | 是 | 是
SDC | easymule | 无 | 无 | 软 | 硬 | 不存在 | 是 | 是
SDC | lite | 无 | 无 | 无 | 硬 | 不存在 | 是 | 是
Official | - | 无 | 无 | 无 | 硬 | 不存在 | 无 | 否
