﻿Strict DLP Chinese(SDC) documents
=====

* **ReadMe**
    * 主要说明文档，包括项目的完整使用说明和大部分细节的详细介绍
    * 主要說明文檔，包括專案的完整使用說明和大部分細節的詳細介紹
* **Changelog**
    * 详细更新日志
    * 詳細更新日誌
