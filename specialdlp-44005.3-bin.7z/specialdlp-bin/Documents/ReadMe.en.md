﻿Type | DLP version | VeryCD Mod | VeryCD Tag | easyMule(1) | easyMule(2) | Default NickNames | More Leechers | Fix Bugs
:---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: 
SDC | all-verycd | Soft | No | Soft | Hard | N/A | Yes | Yes
SDC | verycd-tag | Soft | Soft | Soft | Hard | Soft | Yes | Yes
SDC | verycd-nickname | No | No | No | Hard | Soft | Yes | Yes
SDC | easymule | No | No | Soft | Hard | N/A | Yes | Yes
SDC | lite | No | No | No | Hard | N/A | Yes | Yes
Official | - | No | No | No | Hard | N/A | No | No
