﻿類型 | DLP 版本 | VeryCD Mod | VeryCD Tag | easyMule(1) | easyMule(2) | 預設昵稱的 VeryCD 和 easyMule(1) | 其他更多吸血驢 | 修正官方問題
:---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---:
SDC | all-verycd | 軟 | 無 | 軟 | 硬 | 不存在 | 是 | 是
SDC | verycd-tag | 軟 | 軟 | 軟 | 硬 | 軟 | 是 | 是
SDC | verycd-nickname | 無 | 無 | 無 | 硬 | 軟 | 是 | 是
SDC | easymule | 無 | 無 | 軟 | 硬 | 不存在 | 是 | 是
SDC | lite | 無 | 無 | 無 | 硬 | 不存在 | 是 | 是
Official | - | 無 | 無 | 無 | 硬 | 不存在 | 無 | 否
